package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HeaderController {

	@PostMapping("/header")
	public ResponseEntity<Map<String,String>> createHeader(
			@RequestHeader(value="Accept") String acceptHeader,
			@RequestHeader(value="Authorization") String authorization,
			@RequestHeader(value="student") String st) {
		
		Map<String ,String> returnValue=new HashMap<String,String>();
		returnValue.put("Accept", acceptHeader);
		returnValue.put("Authorization", authorization);
		returnValue.put("student", st);
		return ResponseEntity.status(HttpStatus.OK).body(returnValue);
	}
	
	@GetMapping("/h")
	public String getHeader(@RequestHeader Map<String,String> mapValue) {
		System.out.println("this is my header : "+mapValue);
		return "success";
	}
	
	@PostMapping("/customheader")
	public ResponseEntity<Header> createHeaderBasedContractDigital(
	@RequestHeader(value="callName") String callName,
    @RequestHeader(value="wiName") String winame,
    @RequestHeader(value="reqid") String rqid,
    @RequestHeader(value="activityName") String ActivityName) {
		
		Header header = new Header();
		header.setWiName(winame);
		header.setActivityName(ActivityName);
		header.setCallName(callName);	
		header.setReqid(rqid);
		return ResponseEntity.status(HttpStatus.OK).body(header);
	}
	
}
