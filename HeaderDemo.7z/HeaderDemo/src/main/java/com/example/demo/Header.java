package com.example.demo;

import org.json.JSONObject;

public class Header {
	
	private String wiName;
	private String channelType;
	private String callName;
	private String activityName;
	private String userName;
	private String sessionID;
	private String language;
	private String dossierId;
	private String queryParameters;
	private String workitemID;
	private String reqid;
	private String CIC;
	
	public String getWiName() {
		return wiName;
	}
	public void setWiName(String wiName) {
		this.wiName = wiName;
	}
	public String getChannelType() {
		return channelType;
	}
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}
	public String getCallName() {
		return callName;
	}
	public void setCallName(String callName) {
		this.callName = callName;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getSessionID() {
		return sessionID;
	}
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getDossierId() {
		return dossierId;
	}
	public void setDossierId(String dossierId) {
		this.dossierId = dossierId;
	}
	public String getQueryParameters() {
		return queryParameters;
	}
	public void setQueryParameters(String queryParameters) {
		this.queryParameters = queryParameters;
	}
	public String getWorkitemID() {
		return workitemID;
	}
	public void setWorkitemID(String workitemID) {
		this.workitemID = workitemID;
	}
	public String getReqid() {
		return reqid;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getCIC() {
		return CIC;
	}
	public void setCIC(String cIC) {
		CIC = cIC;
	}
	
	public JSONObject toJSON(Header header) {
		
		JSONObject json = new JSONObject();
		 
		json.put("wiName",header.getWiName());
		json.put("reqid",header.getReqid());
		json.put("callName",header.getCallName());
		json.put("activityName",header.getActivityName());
//		json.put("channelType",header.getChannelType());
//		json.put("userName",header.getUserName());
//		json.put("sessionID",header.getSessionID());
//		json.put("language",header.getLanguage());
//		json.put("dossierId",header.getDossierId());
//		json.put("queryParameters",header.getQueryParameters());
//		json.put("workitemID",header.getWorkitemID());
		
//		json.put("CIC",header.getCIC());
		return json;
	}

}
